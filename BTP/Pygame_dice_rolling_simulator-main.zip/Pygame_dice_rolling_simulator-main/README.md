# Pygame_dice_rolling_simulator
get a random result each time you roll the dice

you need pygame module to run that

please give me your comments after executing that code
